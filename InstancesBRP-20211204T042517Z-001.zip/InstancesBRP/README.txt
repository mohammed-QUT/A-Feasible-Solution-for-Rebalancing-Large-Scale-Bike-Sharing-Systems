Instances are organized as follows

- number of vertices (the depot is included)
- array of demands (the first one is 0 since is the demand at the depot)
- vehicles capacity
- distance matrix